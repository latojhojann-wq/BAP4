package com.visorurl.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
